export HISTSIZE=10000
export HISTTIMEFORMAT="%F %T `whoami` "
